# Qwatch Tracker Bridge (Android)

Android 12–15 (Pixel 9 Pro tested) BLE notification bridge for Qwatch Pro / JYouPro / KeepHealth fitness trackers.

## Option 1: Build the APK in the Cloud (No Android Studio Needed)

This project includes `.github/workflows/build-apk.yml`:

1. Create a new empty repository on GitHub (private or public).
2. Upload the unzipped `TrackerNotifier` folder contents (including `.github/workflows/build-apk.yml`).
3. Open the **Actions** tab → **Build Android APK** → wait ~2 minutes.
4. Download the **QwatchTrackerBridge-debug-apk** artifact, unzip it, and install `app-debug.apk` on your Pixel 9 Pro.

## Option 2: Build the APK Locally with Android Studio

1. Open the `TrackerNotifier` folder in **Android Studio**.
2. Wait for Gradle sync to finish.
3. Click **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
4. Find the compiled APK at:
   `app/build/outputs/apk/debug/app-debug.apk`

Or from the command line (with JDK 17 + Android SDK installed):

```bash
gradle assembleDebug
```

## Installing on Pixel 9 Pro (Android 14 / 15)

1. Transfer `app-debug.apk` to your Pixel and install it.
2. Open **Settings → Apps → Qwatch Tracker Bridge → ⋮ (top right) → Allow restricted settings** (required by Android 14+ for sideloaded Notification Listeners).
3. Launch **Qwatch Tracker Bridge**, tap **1. Notif Access**, and enable notification access.
4. Tap **2. Start Service**, grant Bluetooth & Notification permissions, select your allowed apps, and tap **Test Buzz**.
